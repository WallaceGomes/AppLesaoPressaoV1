import { Component, OnInit } from '@angular/core';
import { Ficha } from './../fichas/ficha.model';

@Component({
  selector: 'app-pagina-listar-fichas',
  templateUrl: './pagina-listar-fichas.page.html',
  styleUrls: ['./pagina-listar-fichas.page.scss'],
})
export class PaginaListarFichasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
