export class Paciente {
    id: string;
    nome: string;
    matricula: string;
    dataInternacao: string
}