import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-listar-pacientes',
  templateUrl: './pagina-listar-pacientes.page.html',
  styleUrls: ['./pagina-listar-pacientes.page.scss'],
})
export class PaginaListarPacientesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
