import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-cadastro-pacientes',
  templateUrl: './pagina-cadastro-pacientes.page.html',
  styleUrls: ['./pagina-cadastro-pacientes.page.scss'],
})
export class PaginaCadastroPacientesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
