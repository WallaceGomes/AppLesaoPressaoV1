export interface Ficha {
    id: string;
    nome: string;
    matricula: string;
    dataInternacao: string;
    leito: string;
    data: string;
    percepSens: any;
    umidade: any;
    atividade: any;
    mobilidade: any;
    nutricao: any;
    fricscisal: any;
    score: any;
}
