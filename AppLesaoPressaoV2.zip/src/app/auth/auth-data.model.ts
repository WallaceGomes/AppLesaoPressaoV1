export interface AuthData {
    email: string;
    senha: string;
}