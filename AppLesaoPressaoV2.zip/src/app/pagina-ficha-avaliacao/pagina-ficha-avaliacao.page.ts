import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-ficha-avaliacao',
  templateUrl: './pagina-ficha-avaliacao.page.html',
  styleUrls: ['./pagina-ficha-avaliacao.page.scss'],
})
export class PaginaFichaAvaliacaoPage implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
