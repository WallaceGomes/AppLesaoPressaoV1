import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-cadastro',
  templateUrl: './pagina-cadastro.page.html',
  styleUrls: ['./pagina-cadastro.page.scss'],
})
export class PaginaCadastroPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
