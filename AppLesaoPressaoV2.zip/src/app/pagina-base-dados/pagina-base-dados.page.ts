import { Component, OnInit } from '@angular/core';
import { Ficha } from './../fichas/ficha.model';

@Component({
  selector: 'app-pagina-base-dados',
  templateUrl: './pagina-base-dados.page.html',
  styleUrls: ['./pagina-base-dados.page.scss'],
})
export class PaginaBaseDadosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
