import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-login',
  templateUrl: './pagina-login.page.html',
  styleUrls: ['./pagina-login.page.scss'],
})
export class PaginaLoginPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
