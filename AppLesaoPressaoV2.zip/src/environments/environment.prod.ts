export const environment = {
  production: true,
  apiUrl: "http://applesaopressaov1-env.md8nxtpwmx.sa-east-1.elasticbeanstalk.com/api"
};
